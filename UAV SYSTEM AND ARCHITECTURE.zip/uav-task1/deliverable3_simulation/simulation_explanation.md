# Deliverable 3: Simulation Explanation

**Course:** UAV Design & Simulation Internship — Task 1  
**Topic:** Python-Based UAV Altitude Simulation  

---

## File 1: `uav_altitude_simulation.py` — Base Model

### What It Does
Simulates a quadcopter climbing with a **constant thrust of 20 N** over 10 seconds. This is the starter code from the task brief.

### Physics Used
```
Net Force    = Thrust - (mass × gravity)
             = 20 N - (1.5 kg × 9.81 m/s²)
             = 20 - 14.715
             = 5.285 N  (upward)

Acceleration = Net Force / mass
             = 5.285 / 1.5
             = 3.52 m/s²

Each timestep (dt = 0.1s):
    velocity += acceleration × dt
    height   += velocity × dt
```

### What the Graph Shows
- **Height vs Time:** The drone continuously accelerates upward — height increases parabolically (like a ball thrown up but never coming down).
- **Velocity vs Time:** Linear increase — constant acceleration causes linearly growing velocity.

### Key Observation
With constant thrust > weight, the drone **never stops climbing**. This is unrealistic for flight — it needs a controller to stabilize at a target altitude.

---

## File 2: `uav_altitude_stabilized.py` — PD Controller

### What It Does
Adds a **Proportional-Derivative (PD) controller** that dynamically adjusts thrust to stabilize the drone at exactly 10 meters altitude.

### Two-Phase Operation

**Phase 1 (0–3 seconds): Takeoff**
- A constant high thrust (25 N) is applied to lift the drone off the ground.
- The drone climbs quickly toward the target altitude.

**Phase 2 (3+ seconds): Stabilization**
- The PD controller takes over:
```
error  = target_height - current_height
thrust = hover_thrust + Kp × error + Kd × d_error/dt
```
- If the drone is **below** target → error is positive → thrust increases
- If the drone is **above** target → error is negative → thrust decreases
- The D-term (derivative) **damps oscillations** — prevents overshoot bouncing

### Controller Tuning
| Parameter | Value | Effect |
|-----------|-------|--------|
| `Kp = 5.0` | Proportional gain | Higher = faster response, but may overshoot |
| `Kd = 3.0` | Derivative gain | Higher = more damping, smoother convergence |
| `hover_thrust = 14.715 N` | Feedforward term | Exact thrust to cancel gravity |

### What the Graphs Show

**Plot 1 — Altitude Response:**
- Drone climbs rapidly from 0 to ~10m
- Slight overshoot due to momentum
- PD controller corrects and settles at exactly 10m
- Steady-state error approaches ~0

**Plot 2 — Velocity Response:**
- High positive velocity during climb
- Velocity oscillates near zero as controller dampens motion
- Converges to 0 m/s at hover (as expected — stationary hover)

**Plot 3 — Thrust Command:**
- High thrust during takeoff phase
- Thrust settles at hover_thrust (14.715 N) once stable
- Small variations as controller makes micro-corrections

---

## Experiment: Modifying Thrust Values

| Thrust (N) | Behavior |
|------------|----------|
| < 14.715 N | Drone does not lift off (thrust < weight) |
| = 14.715 N | Drone floats — net force = 0, stays at ground if starting from rest |
| 20 N (base) | Continuous climbing, accelerates indefinitely |
| 25 N (takeoff) | Fast climb, suitable for controlled ascent |
| 40 N (max clamped) | Very fast ascent, controller prevents runaway |

---

## Connection to Real Drones

This simulation is a simplified 1D version of what real flight controllers (Pixhawk, ArduPilot) do:
- The **altitude hold mode** in Pixhawk uses a similar PID loop reading barometer data
- The **hover_thrust feedforward** concept is used in real autotune algorithms
- The simulation's `dt` represents the flight controller's loop rate (50Hz here = 50ms loop)

---

*Simulation explanation prepared as part of Maincrafts Technology UAV Internship — Task 1*

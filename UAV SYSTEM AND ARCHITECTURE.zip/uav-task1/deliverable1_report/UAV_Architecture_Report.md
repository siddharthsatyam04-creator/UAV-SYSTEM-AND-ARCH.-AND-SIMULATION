# Deliverable 1: UAV Architecture Report

**Course:** UAV Design & Simulation Internship — Task 1  
**Topic:** UAV Fundamentals & Component Architecture  

---

## 1. Types of UAVs

### A. Multi-Rotor (Quadcopter)
A multi-rotor UAV uses multiple rotors (typically 4, 6, or 8) to generate lift and control movement. Each rotor spins in alternating directions to cancel out torque, maintaining stability without a tail rotor.

**Key Characteristics:**
- Vertical takeoff and landing (VTOL)
- Hover capability
- High maneuverability in confined spaces
- Limited flight time (typically 20–40 minutes on LiPo battery)

**Industry Applications:**
- Aerial photography and videography (DJI Mavic, Phantom series)
- Package delivery (Amazon Prime Air)
- Search and rescue
- Infrastructure inspection (power lines, bridges)

---

### B. Fixed-Wing UAV
Fixed-wing UAVs generate lift through aerodynamic wing surfaces, similar to conventional aircraft. They require forward motion to maintain lift, meaning they cannot hover.

**Key Characteristics:**
- High efficiency and long endurance (hours of flight)
- Large coverage area per flight
- Requires runway, catapult launch, or hand launch
- Higher cruise speeds

**Industry Applications:**
- Agricultural mapping and precision farming
- Military reconnaissance and surveillance
- Disaster response and terrain mapping
- Pipeline and border patrol

---

### C. Hybrid VTOL UAV
Hybrid VTOL (Vertical Takeoff and Landing) UAVs combine multi-rotor and fixed-wing designs. They take off and land vertically using rotors, then transition to efficient fixed-wing cruise flight.

**Key Characteristics:**
- Best of both worlds: hover + long-range cruise
- Mechanically more complex
- Used in advanced commercial and defense operations

**Industry Applications:**
- Long-range delivery logistics
- Military ISR (Intelligence, Surveillance, Reconnaissance)
- Maritime patrol
- Advanced urban air mobility

---

## 2. UAV Components — What Each Part Does

### A. Frame
The structural skeleton of the drone. Made from carbon fiber, aluminum, or plastic. Provides mounting points for all components. Frame geometry (H-frame, X-frame, etc.) affects aerodynamics and weight distribution.

### B. Brushless Motors
Electric motors that convert electrical energy into mechanical rotation to spin the propellers. They are preferred over brushed motors because they are more efficient, generate less heat, and have longer lifespans. Each motor in a quadcopter is rated by KV (RPM per volt) — a higher KV means faster rotation at lower torque, suitable for smaller propellers.

### C. ESC (Electronic Speed Controller)
The ESC sits between the flight controller and each motor. It receives throttle signals (PWM) from the flight controller and regulates the power delivered from the battery to the brushless motor. Each motor has its own ESC. The ESC also converts DC battery power into 3-phase AC to drive brushless motors.

### D. Flight Controller (Pixhawk / APM)
The brain of the drone. It reads sensor data (IMU, GPS, barometer), runs stabilization algorithms (PID controllers), and sends corrective speed commands to each ESC. Popular flight controllers include Pixhawk 4, ArduPilot-based APM, and Betaflight boards for racing drones.

### E. Propellers
Convert motor rotation into thrust. Designed with specific pitch (angle of blade) and diameter. Two propellers spin clockwise (CW) and two spin counter-clockwise (CCW) in a standard quadcopter to cancel rotational torque and prevent yaw drift.

### F. LiPo Battery (Lithium Polymer)
The power source. Rated in capacity (mAh), voltage (cell count: 3S = 11.1V, 4S = 14.8V), and discharge rate (C-rating). Higher voltage = more power to motors. Higher C-rating = battery can supply high current bursts without damage.

### G. GPS Module
Provides absolute position data (latitude, longitude, altitude). Used for autonomous waypoint navigation, Return-to-Home (RTH), position hold, and geofencing. Typically uses u-blox M8N or M9N chipsets.

### H. IMU (Inertial Measurement Unit)
Combines a 3-axis accelerometer and 3-axis gyroscope. The accelerometer measures linear acceleration; the gyroscope measures angular velocity. Together they give the flight controller real-time attitude data (roll, pitch, yaw angles and rates). A barometer is often included to estimate altitude from air pressure.

---

## 3. Power Flow: Battery → Motors

```
LiPo Battery
    │
    ▼
Power Distribution Board (PDB)
    │
    ├──► ESC 1 ──► Motor 1 (Front-Left, CCW)
    ├──► ESC 2 ──► Motor 2 (Front-Right, CW)
    ├──► ESC 3 ──► Motor 3 (Rear-Left, CW)
    └──► ESC 4 ──► Motor 4 (Rear-Right, CCW)
                        │
                  BEC (5V regulator)
                        │
                  Flight Controller
                  (Pixhawk/APM)
```

**Detailed Flow:**
1. The LiPo battery supplies raw DC voltage (11.1V–22.2V depending on cell count).
2. The Power Distribution Board (PDB) splits this power to all four ESCs.
3. Each ESC converts DC to 3-phase AC and modulates it to control motor speed.
4. The ESC also includes a BEC (Battery Eliminator Circuit) that steps down voltage to 5V to power the flight controller and receiver.
5. The flight controller sends PWM signals (1000–2000 µs pulse width) to each ESC to command motor speed.

---

## 4. How the Flight Controller Stabilizes the Drone

The flight controller runs a **PID (Proportional-Integral-Derivative) control loop** at high frequency (typically 400Hz–1kHz):

1. **Sense:** The IMU reads the current roll, pitch, and yaw angles and angular rates.
2. **Compare:** The controller compares the current attitude to the desired (setpoint) attitude from the pilot's stick inputs.
3. **Correct:** If there is an error (e.g., the drone is tilting right), the controller increases speed on the right motors and decreases speed on the left motors to bring the drone back to level.
4. **Repeat:** This loop runs hundreds of times per second, making imperceptible corrections constantly.

**Example — Altitude Hold:**
- Barometer reads current altitude.
- If the drone drops, the controller increases thrust on all four motors equally.
- If the drone rises, it reduces thrust proportionally.

This closed-loop feedback system is what makes modern drones appear to "float" stably in the air without constant pilot input.

---

## 5. Summary Table

| Component | Function | Key Spec |
|-----------|----------|----------|
| Frame | Structural support | Material: Carbon Fiber |
| Brushless Motor | Generates rotation/thrust | KV rating |
| ESC | Controls motor speed | Amp rating (e.g., 30A) |
| Flight Controller | Brain, stabilization | Pixhawk 4, APM |
| Propellers | Convert rotation to thrust | Size (e.g., 10x4.5") |
| LiPo Battery | Power source | Voltage (3S/4S), Capacity (mAh) |
| GPS Module | Position & navigation | u-blox M8N |
| IMU | Attitude sensing | 3-axis Accel + Gyro |

---

*Report prepared as part of Maincrafts Technology UAV Internship — Task 1*
